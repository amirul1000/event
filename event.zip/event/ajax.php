<?php
    session_start();
	
    $parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
    require_once( $parse_uri[0] . 'wp-load.php' );
	
    global $wpdb;  
	$cmd = $_REQUEST['cmd'];
	if(isset($cmd))
	{
		switch($cmd)
		{
		  case 'add':
		        $images   = explode("each",$_SESSION['image']);			   			
				if(empty($_REQUEST['id']))
				{    $table_name = $wpdb->prefix."event";
					 $wpdb->insert($table_name, 
							array(
							      'user_id' => get_current_user_id(),						  
								  'event_title' => $_POST['event_title'],
								  'images' => $_POST['images'],
								  'event_type' => $_POST['event_type'],
								  'start_date_time' => $_POST['start_date_time'],								  
								  'end_date_time' => $_POST['end_date_time'],
								  'address' => $_POST['address'],
								  'city' => $_POST['city'],
								  'state' => $_POST['state'],
								  'ticket_price' => $_POST['ticket_price'],
								  'ticket_qty' => $_POST['ticket_qty'],
								  'description' => $_POST['description']
								  )
							);
					$id = mysql_insert_id();
		            if($id>0)
					{
					  $message = "Event has been added success fully";					  
					  echo $message;	
					}
				}
				else
				{
					 $table_name = $wpdb->prefix."event";
					 $affected = $wpdb->update($table_name, 
							array(
								  'user_id' => get_current_user_id(),								  
								  'event_title' => $_POST['event_title'],
								  //'images' => $_POST['images'],
								  'event_type' => $_POST['event_type'],
								  'start_date_time' => $_POST['start_date_time'],								  
								  'end_date_time' => $_POST['end_date_time'],
								  'address' => $_POST['address'],
								  'city' => $_POST['city'],
								  'state' => $_POST['state'],
								  'ticket_price' => $_POST['ticket_price'],
								  'ticket_qty' => $_POST['ticket_qty'],
								  'description' => $_POST['description']
								  )  ,
								   array('id'=>$_REQUEST['id'])
								); 
					 $id = $_REQUEST['id'];
					if($affected==TRUE)
					{
					  $message = "Event has been updated successfully";
					  echo $message;		 
					}
				}
				if(count($images)>0)
				{
					//delete images
					global $wpdb;					
					$Id = $_REQUEST['id'];					
					$table_name = $wpdb->prefix."images";
					$sql = "DELETE FROM  ".$table_name."  WHERE event_id='".$id."'";
					$res =   $wpdb->query($wpdb->prepare($sql)); 
					//add image
					for($i=0;$i<count($images);$i++)
					{
						$wpdb->insert($table_name, 
									array(
										  'event_id' => $id,						  
										  'image' => $images[$i]
										  )
									);
					 }
				 }
	      }
	 }
?>