<?php
	/*
	Plugin Name: Event
	Plugin URI: 
	Description: Event
	Version: 1.1
	Author: Amirul Momenin
	Author URI: 
	License: GPL
	*/
	//http://www.jqueryscript.net/demo/Simple-Clean-jQuery-Vertical-Product-Gallery/#
	ob_start(); // line 1
	session_start(); // line 2
	$PLUGIN_URL = plugin_dir_url(__FILE__);
	define('PLUGIN_URL',substr($PLUGIN_URL,0,strlen($PLUGIN_URL)-1));
	define('PLUGIN_PATH', str_replace('\\', '/', dirname(__FILE__)) );
	
	
	add_action('admin_menu', 'event_add_pages'); 
	function event_add_pages() {
		add_menu_page("Event", "Event", "activate_plugins", "event", "admin_event");
	}
	
	function admin_event() { 
		include_once dirname(__FILE__) . '/admin/event/index.php';
	}
	
	register_activation_hook(__FILE__,'event_install'); 
	register_deactivation_hook( __FILE__, 'event_remove' );
	function event_install()
	 {  
		//create page
		create_page("addevent");
		create_page("listevent");
		
		global $neocart_db_version;
		$neocart_db_version = "1.0";
		global $wpdb;
		global $neocart_db_version;
	
	   
		$table_name = $wpdb->prefix."event";
		$sqlevent = "CREATE TABLE $table_name(
					  id int(10) NOT NULL AUTO_INCREMENT,
					  user_id int(10) NOT NULL,
					  event_title varchar(256) DEFAULT NULL,
					  images varchar(256) DEFAULT NULL,
					  event_type  varchar(256) DEFAULT NULL,
					  start_date_time varchar(256) NOT NULL,
					  end_date_time varchar(256) NOT NULL,
					  address varchar(256) NOT NULL,
					  city varchar(256) NOT NULL,
					  state varchar(256) NOT NULL,
					  ticket_price varchar(256) DEFAULT NULL,
					  ticket_qty varchar(256) DEFAULT NULL,
					  description varchar(256) NOT NULL,
					  PRIMARY KEY (id)
					);";
					
					
		$table_name = $wpdb->prefix."images";
		$sqlimages = "CREATE TABLE $table_name(
					  id int(10) NOT NULL AUTO_INCREMENT,
					  event_id int(10) NOT NULL,
					  image TEXT DEFAULT NULL,
					  PRIMARY KEY (id)
					);";			
					
					
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	 
		dbDelta($sqlevent);
		dbDelta($sqlimages);
		
		add_option("event_db_version", $neocart_db_version);
		
		//create page
		//include_once dirname(__FILE__) . '/create-page.php';
		
	}
	function create_page($title)
	{
		global $wpdb; 
		
		//Products
		$the_page_title = $title;
		$the_page_name = $title;
		
		delete_option("event_page_title");
		add_option("event_page_title", $the_page_title, '', 'yes');
		
		delete_option("event_page_name");
		add_option("event_page_name", $the_page_name, '', 'yes');
		
		delete_option("event_page_id");
		add_option("event_page_id", '0', '', 'yes');
		
		$the_page = get_page_by_title( $the_page_title );
		if ( ! $the_page ) {
			$_p = array();
			$_p['post_title'] = $the_page_title;
			$_p['post_content'] = "[".$title."]";
			$_p['post_status'] = 'publish';
			$_p['post_type'] = 'page';
			$_p['comment_status'] = 'closed';
			$_p['ping_status'] = 'closed';
			$_p['post_category'] = array(1);
			$the_page_id = wp_insert_post( $_p );
		}
	}
	
	function event_remove()
	{
		global $wpdb;
		
		$table_name = $wpdb->prefix."event";
		$sql = "DROP TABLE ". $table_name;
		$wpdb->query($sql);
		
		
		$table_name = $wpdb->prefix."images";
		$sql = "DROP TABLE ". $table_name;
		$wpdb->query($sql);
		
		
		//remove page
		global $wpdb;
	
		$the_page_title = get_option( "event_page_title" );
		$the_page_name = get_option( "event_page_name" );
		$the_page_id = get_option( 'event_page_id' );
		if( $the_page_id ) {
			wp_delete_post( $the_page_id ); 
		}
		delete_option("event_page_title");
		delete_option("event_page_name");
		delete_option("event_page_id");
	}
	
	//short code Events
	function add_event_sort_code_func( $atts ) {
		include_once dirname(__FILE__) . '/add_event.php';
	}
	add_shortcode( 'addevent', 'add_event_sort_code_func' );
	
	function list_event_sort_code_func( $atts ) {
		include_once dirname(__FILE__) . '/list_event.php';
	}
	add_shortcode( 'listevent', 'list_event_sort_code_func' );
	
?>