<?php
    global $wpdb;  
	$cmd = $_REQUEST['cmd'];
	if(isset($cmd))
	{
		switch($cmd)
		{
			case "edit":
				    $Id = $_REQUEST['id'];
					if( !empty($_REQUEST['id'] ))
					{
						global $wpdb;
						$table_name = $wpdb->prefix."event";
						$sql = "SELECT * from  ".$table_name."  WHERE id='".$_REQUEST['id']."'";
						$res =  $wpdb->get_results($sql, OBJECT);
						if($wpdb->num_rows === 1)
						{
							$Id        = $res[0]->id;  
							$user_id    = $res[0]->user_id;
							$event_title    = $res[0]->event_title;
							$event_type    = $res[0]->event_type;
							$start_date_time    = $res[0]->start_date_time;
							$end_date_time    = $res[0]->end_date_time;
							$address    = $res[0]->address;
							$city    = $res[0]->city;
							$state    = $res[0]->state;
							$ticket_price = $res[0]->ticket_price;
							$ticket_qty    = $res[0]->ticket_qty;
							$description    = $res[0]->description;
						}
					 }  	
	      }
	 }
?>

<?php get_header(); ?>
<?php get_sidebar('profile-left'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo plugin_dir_url(__FILE__) ?>datetimepicker-master/jquery.datetimepicker.css"/>
<style type="text/css">
	.custom-date-style {
		background-color: red !important;
	}
	.input{	
	}
	.input-wide{
		width: 500px;
	}
</style>

<script language="javascript">
  //$( document ).ready(function() {
	 //  $("#btn_submit").click( function() {
		   function submit_data()
		   {
		        $("#message").html("");
				$("#spinner").html('<img src="<?php echo plugin_dir_url(__FILE__) ?>images/spinner.gif" alt="Wait" />');        
				
				$.ajax({
				type: "POST",
				url: '<?php echo plugin_dir_url(__FILE__) ?>ajax.php',
				data: {
					cmd : $("#cmd").val(),
					id : $("#id").val(),
					event_title : $("#event_title").val(),
					event_type : $("#event_type").val(),
					start_date_time : $("#datetimepicker1").val(),
					end_date_time : $("#datetimepicker2").val(),
					address : $("#address").val(),
					city : $("#city").val(),
					state : $("#state").val(),
					ticket_qty : $("#ticket_qty").val(),
					description : $("#description").val()
				  },
				success: function(data) {
				   $("#message").html(data);
				   $("#spinner").html('');
				}
		   });
		 }
				
				//)}
	//});
</script>

<div class="column fivecol">   
    <h3><?=ucwords(str_replace("_"," ","event"))?></h3><br />
    <div id="message"></div>
     
     <div id="spinner"></div>
    <table cellspacing="3" cellpadding="3" border="0" align="center" width="98%" class="bdr">
     <tr>
      <td>  
            <table cellspacing="3" cellpadding="3" border="0" align="center" class="bodytext" width="100%">  
                 <tr>
                     <td valign="top">Title</td>
                     <td>
                        <input type="text" name="event_title" id="event_title"  value="<?=$event_title?>" class="textbox">
                     </td>
                 </tr>
                  <tr>
                     <td valign="top">Images</td>
                     <td>
                         <link href="<?php echo plugin_dir_url(__FILE__) ?>upload/style.css" rel="stylesheet" type="text/css" />
                         <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
						 <script type="text/javascript" src="<?php echo plugin_dir_url(__FILE__) ?>upload/jquery.form.js"></script>
                         <script type="text/javascript">
							$(document).ready(function(){
								$('#images').on('change',function(){
									$('#multiple_upload_form').ajaxForm({
										target:'#images_preview',
										beforeSubmit:function(e){
											$('.uploading').show();
										},
										success:function(e){
											$('.uploading').hide();
										},
										error:function(e){
										}
									}).submit();
								});
							});
                         </script>
                         <div style="margin-top:50px;">
                            <div class="upload_div">
                            <form method="post" name="multiple_upload_form" id="multiple_upload_form" enctype="multipart/form-data" action="<?php echo plugin_dir_url(__FILE__) ?>upload/upload.php">
                                <input type="hidden" name="image_form_submit" value="1"/>
                                    <label>Choose Image</label>
                                    <input type="file" name="images[]" id="images" multiple >
                                <div class="uploading none">
                                    <label>&nbsp;</label>
                                    <img src="<?php echo plugin_dir_url(__FILE__) ?>upload/uploading.gif"/>
                                </div>
                            </form>
                            </div>
                            
                            <div class="gallery" id="images_preview"></div>
                        </div>
                     </td>
                 </tr>
                  <tr>
                     <td>Event type</td>
                     <td>
                        <select name="event_type" id="event_type"  value="<?=$event_type?>" class="textbox">
                          <option value="Speech" <?php if($event_type=='Speech'){ echo "selected"; }  ?>>Speech</option>
                          <option value="Recreation" <?php if($event_type=='Recreation'){ echo "selected"; }  ?>>Recreation</option>
                          <option value="Tour" <?php if($event_type=='Tour'){ echo "selected"; }  ?>>Tour</option>
                          <option value="Concert" <?php if($event_type=='Concert'){ echo "selected"; }  ?>>Concert</option>
                          <option value="Other" <?php if($event_type=='Other'){ echo "selected"; }  ?>>Other</option>
                        </select>
                     </td>
                   </tr>
                   <tr>
                     <td>Start date time</td>
                     <td>
                        <input type="text" name="start_date_time" id="datetimepicker1"  value="<?=$start_date_time?>" class="datetimepicker">
                     </td>
                 </tr>
                  <tr>
                     <td>End date time</td>
                     <td>
                        <input type="text" name="end_date_time" id="datetimepicker2"  value="<?=$end_date_time?>" class="datetimepicker">
                     </td>
                 </tr>
                   <tr>
                     <td>Address</td>
                     <td>
                        <input type="text" name="address" id="address"  value="<?=$address?>" class="textbox">
                     </td>
                 </tr>
                   <tr>
                     <td>City</td>
                     <td>
                        <input type="text" name="city" id="city"  value="<?=$city?>" class="textbox">
                     </td>
                 </tr>
                   <tr>
                     <td>State</td>
                     <td>
                        <input type="text" name="state" id="state"  value="<?=$state?>" class="textbox">
                     </td>
                 </tr>
                 <tr>
                     <td>Ticket price</td>
                     <td>
                        <input type="text" name="ticket_price" id="ticket_price"  value="<?=$ticket_price?>" class="textbox">
                     </td>
                 </tr>
                 <tr>
                     <td>Ticket qty</td>
                     <td>
                        <input type="text" name="ticket_qty" id="ticket_qty"  value="<?=$ticket_qty?>" class="textbox">
                     </td>
                 </tr>
                 <tr>
                     <td>Description</td>
                     <td>
                        <textarea name="description" id="description"><?=$description?></textarea>
                     </td>
                 </tr>
                 <tr> 
                     <td align="right"></td>
                     <td>
                        <input type="hidden" name="cmd" id="cmd" value="add">
                        <input type="hidden" name="id" id="id" value="<?=$Id?>">			
                        <input type="button" name="btn_submit" id="btn_submit" value="submit" class="button_blue" onclick="submit_data();">
                     </td>     
                 </tr>
            </table>
      </td>
     </tr>
    </table>
</div>


<!--<script src="<?php echo plugin_dir_url(__FILE__) ?>datetimepicker-master/jquery.js"></script>-->
<script src="<?php echo plugin_dir_url(__FILE__) ?>datetimepicker-master/build/jquery.datetimepicker.full.js"></script>



<script>/*
	window.onerror = function(errorMsg) {
		$('#console').html($('#console').html()+'<br>'+errorMsg)
	}*/
	
	$.datetimepicker.setLocale('en');
	
	/*$('#datetimepicker').datetimepicker({
	dayOfWeekStart : 1,
	lang:'en',
	disabledDates:['1986/01/08','1986/01/09','1986/01/10'],
	startDate:	'1986/01/05'
	});*/
	
	$('#datetimepicker1').datetimepicker({
	dayOfWeekStart : 1,
	lang:'en',
	disabledDates:['1986/01/08','1986/01/09','1986/01/10'],
	startDate:	'<?=date("Y/m/d")?>'
	});
	
	$('#datetimepicker2').datetimepicker({
	dayOfWeekStart : 1,
	lang:'en',
	disabledDates:['1986/01/08','1986/01/09','1986/01/10'],
	startDate:	'<?=date("Y/m/d")?>'
	});
	//$('#datetimepicker1').datetimepicker({value:'2015/04/15 05:03',step:10});
	
	$('.some_class').datetimepicker();
</script>
<?php get_sidebar('profile-right'); ?>
<?php get_footer(); ?>		