<?php
    global $wpdb;  
	$cmd = $_REQUEST['cmd'];
	if(isset($cmd))
	{
		switch($cmd)
		{
		    case 'delete': 
					global $wpdb;					
				    $Id = $_REQUEST['id'];					
					$table_name = $wpdb->prefix."event";
					$sql = "DELETE FROM  ".$table_name."  WHERE  user_id='".get_current_user_id()."'  AND
					                                             id='".$_REQUEST['id']."'";
					$res =   $wpdb->query($wpdb->prepare($sql));
					//delete images
					$table_name = $wpdb->prefix."images";
					$sql = "DELETE FROM  ".$table_name."  WHERE event_id='".$_REQUEST['id']."'";
					$res =   $wpdb->query($wpdb->prepare($sql)); 
				break; 						   	
		}
	}
?>
<?php get_header(); ?>
<?php get_sidebar('profile-left'); ?>
<div class="column fivecol">
	<?=ucwords(str_replace("_"," ","event"))?>
	</b>
	<table cellspacing="3" cellpadding="3" border="0"  width="100%" class="bdr">
	  <tr>
		<td><a href="/addevent" class="element-button element-submit primary">Add an event</a>
		  <table cellspacing="1" cellpadding="3" border="0" width="100%" class="bodytext">
			<?php
					
				$rowsPerPage = 10;
				$pageNum = 1;
				if(isset($_REQUEST['page1']))
				{
					$pageNum = $_REQUEST['page1'];
				}
				$offset = ($pageNum - 1) * $rowsPerPage; 
						
				global $wpdb;			
				$table_name = $wpdb->prefix."event";
				$sql = "SELECT * from  ".$table_name." WHERE user_id='".get_current_user_id()."'  ORDER BY id DESC  LIMIT $offset, $rowsPerPage";
				
				$arr =  $wpdb->get_results($sql, OBJECT);	
				
				if($wpdb->num_rows >= 1)
				{
				
				 for($i=0;$i<count($arr);$i++)
				 {
				
				   $rowColor;
		
					if($i % 2 == 0)
					{
						
						$row="#C8C8C8";
					}
					else
					{
						
						$row="#FFFFFF";
					}
					
			 ?>
			<tr>
			  <td valign="top">Title</td>
			  <td><?=$arr[$i]->event_title?></td>
			</tr>
			 <tr>   
			  <td valign="top">Images</td> 
			  <td>
			       <?php 
					$table_name = $wpdb->prefix."images";
					$sql = "SELECT * from  ".$table_name." WHERE event_id='".$arr[$i]->id."' ORDER BY id DESC";
					$arr2 =  $wpdb->get_results($sql, OBJECT);	
					
					if($wpdb->num_rows >= 1)
					{					
						 for($j=0;$j<count($arr2);$j++)
						 {
						   echo '<img src="'.$arr2[$j]->image.'" style="width:100px;height:100px;">';
						 }
					}					
				   ?>
              </td>
			 </tr>
			 <tr>
			  <td valign="top">Event type</td>
			  <td><?=$arr[$i]->event_type?></td>
			 </tr>
			 <tr>
			  <td valign="top">Start date time</td> 
			  <td><?=$arr[$i]->start_date_time?></td>
			 </tr> 
			 <tr>
			  <td valign="top">End date time</td> 
			  <td><?=$arr[$i]->end_date_time?></td>
			 </tr>
			 <tr>
			  <td valign="top">Address</td>
			  <td><?=$arr[$i]->address?></td>
			 </tr>
			 <tr>
			  <td valign="top">City</td>
			  <td><?=$arr[$i]->city?></td>
			 </tr>
			 <tr>
			  <td valign="top">State</td>
			  <td><?=$arr[$i]->state?></td>
			  </tr>
              <tr>
				  <td valign="top">Ticket price</td>
				  <td><?=$arr[$i]->ticket_price?></td>
			  </tr>
			  <tr>
				  <td valign="top">Ticket qty</td>
				  <td><?=$arr[$i]->ticket_qty?></td>
			  </tr>
			  <tr>
				  <td valign="top">Description</td>  
				  <td><?=$arr[$i]->description?></td>
			 </tr>
			 <tr>
			  <td></td>
			  <td nowrap >
				<a href="/addevent?cmd=edit&id=<?=$arr[$i]->id?>" class="element-button element-submit primary">Edit</a> 
			    <a href="/listevent?cmd=delete&id=<?=$arr[$i]->id?>" class="element-button element-submit primary" onClick=" return confirm('Are you sure to delete this item ?');">Delete</a> </td>
			</tr>
			<?php
					  }
					  }
			?>
			<tr>
			<tr>
			  <td colspan="2" align="center">
			  <?php              
					$table_name = $wpdb->prefix."event";
					$sql = "SELECT * from  ".$table_name."  WHERE user_id='".get_current_user_id()."'  ORDER BY id DESC";
					
					$res =  $wpdb->get_results($sql, OBJECT);
					if($wpdb->num_rows >= 1)
					{
						$numrows = count($res);
						$maxPage = ceil($numrows/$rowsPerPage);
						$self = 'listevent?cmd=list';
						$nav  = '';
						
						$start    = ceil($pageNum/5)*5-5+1;
						$end      = ceil($pageNum/5)*5;
						
						if($maxPage<$end)
						{
						  $end  = $maxPage;
						}
						
						for($page = $start; $page <= $end; $page++)
						//for($page = 1; $page <= $maxPage; $page++)
						{
							if ($page == $pageNum)
							{
								$nav .= " $page "; 
							}
							else
							{
								$link = "$self&&page1=$page";
								$nav .= " <a href=\"$link\" style=\"color:#6600FF\">$page</a> ";
							} 
						}
						if ($pageNum > 1)
						{
							$page  = $pageNum - 1;
							$link = "$self&&page1=$page";
							$prev  = " <a href=\"$link\" style=\"color:#6600FF\">[Prev]</a> ";
							$link = "$self&&page1=1";
						   $first = " <a href=\"$link\" style=\"color:#6600FF\">[First Page]</a> ";
						} 
						else
						{
							$prev  = '&nbsp;'; 
							$first = '&nbsp;'; 
						}
					
						if ($pageNum < $maxPage)
						{
							$page = $pageNum + 1;
							$link = "$self&&page1=$page";
							$next = " <a href=\"$link\" style=\"color:#6600FF\">[Next]</a> ";
							$link = "$self&&page1=$maxPage";
							$last = " <a href=\"$link\" style=\"color:#6600FF\">[Last Page]</a> ";
						} 
						else
						{
							$next = '&nbsp;'; 
							$last = '&nbsp;'; 
						}
						
						if($numrows>1)
						{
						  echo $first . $prev . $nav . $next . $last;
						}
					 }	
				?>
			  </td>
			</tr>
	   </table>
	   </td>
	  </tr>
	</table>        
</div>
<?php get_sidebar('profile-right'); ?>
<?php get_footer(); ?>